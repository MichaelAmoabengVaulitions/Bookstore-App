## Bookstore ##

This is a simple bookstore web application which includes and Express RESTful API server and a front end in AngularJS

How to Use:
Run **npm install** and then **node app** in the command line
